#!/bin/bash
mvn test
