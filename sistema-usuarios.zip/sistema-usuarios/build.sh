#!/bin/bash
mvn clean install
